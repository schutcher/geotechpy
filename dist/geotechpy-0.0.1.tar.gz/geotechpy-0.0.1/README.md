Fairly new to programming with Python. 
Using this repository to develop a package for use in geotechnical engineering calculations.

A proper README file to follow.
