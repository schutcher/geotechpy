from pint import UnitRegistry

ureg = UnitRegistry()
Q_ = ureg.Quantity
